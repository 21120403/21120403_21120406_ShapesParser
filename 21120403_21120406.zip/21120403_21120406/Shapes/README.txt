
- Video Demo đồ án: https://youtu.be/St4kLuBD3gM

- Nơi chứa Đồ án và Tài liệu mô tả đồ án:
Link github: https://github.com/21120403/21120403_21120406_ShapesParser

- Thành viên nhóm:
1. Nguyễn Hoàng Quân - 21120403
Email: 21120403@student.hcmus.edu.vn
2. Lê Viết Đạt Trọng - 21120406
Email: 21120406@student.hcmus.edu.vn

- Để chạy chương trình, trước tiên cần phải vào Solution của Project > Build Solution (Ctrl + Shift + B) để khởi chạy các thư viện động DLL. Sau đó chương trình sẽ chạy bình thường.

- Đôi khi chương trình sẽ build lỗi (khá ít gặp) thì khi đó chỉ cần build lại đến khi build thành công hết 7 project là được.

- Chương trình thực thi ( main.exe ) nằm trong thư mục x64 > Debug.

