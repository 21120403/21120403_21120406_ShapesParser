Thành viên nhóm:

1. Nguyễn Hoàng Quân - 21120403
2. Lê Viết Đạt Trọng - 21120406


Để chạy chương trình, trước tiên cần phải vào Solution của Project > Build Solution(Ctrl + Shift + B) để chạy các thư viện động DLL. Sau đó chương trình sẽ chạy bình thường.

Chương trình thực thi ( main.exe ) nằm trong thư mục x64 > Debug.

Nơi chứa Đồ án và Tài liệu mô tả đồ án:
Link github: https://github.com/21120403/21120403_21120406_ShapesParser