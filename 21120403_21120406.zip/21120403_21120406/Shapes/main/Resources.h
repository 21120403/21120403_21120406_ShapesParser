#pragma once

#include <format>
#include"ListShape.h"
#include"Rectangle\Rectangle.h"
#include"Circle\Circle.h"
#include"Square\Square.h"
#include"IParser.h"
#include"SquareParser.h"
#include"RectangleParser.h"
#include"CircleParser.h"
#include"ParserFactory.h"
#include<algorithm>
#include"ListShape.h"
#include"Reader.h"
#include"PrintShape.h"
#include"Triangle/Triangle.h"
#include"TriangleParser.h"
#include"ParallelogramParser.h"
#include"Parallelogram/Parallelogram.h"
#include"Shapes.h"
using std::stoi, std::getline;
using std::setw, std::sort;