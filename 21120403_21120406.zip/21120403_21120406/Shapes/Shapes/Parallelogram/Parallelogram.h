#pragma once
#include"Shapes.h"

class Parallelogram : public Shape
{
protected:
	float _a;
	float _b;
	float _h;
public:
	SHAPELIBRARY_API Parallelogram(float, float, float);
	SHAPELIBRARY_API float area() override;
	SHAPELIBRARY_API string Info()override;
	SHAPELIBRARY_API float perimeter()override;
	SHAPELIBRARY_API string getType()override;
	SHAPELIBRARY_API float getA();
	SHAPELIBRARY_API float getB();
	SHAPELIBRARY_API float getH();
	SHAPELIBRARY_API string geoMetricInfo() override;
};
