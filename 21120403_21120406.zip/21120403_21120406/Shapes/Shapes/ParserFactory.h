﻿#pragma once
#ifndef PARSERFACTORY_H
#define PARSERFACTORY_H
#include"IParser.h"
#include <map>
using std::map;

class ParserFactory
{
private:
    map<string, IParser*> _prototypes;
public:
    /// <summary>
    /// Dependency Injection: Sử dụng tiêm động các đối tượng hình học vào chương trình 
    /// </summary>
    /// <param name="Định dạng hình"></param>
    /// <param name="Đối tượng hình học được tiêm động"></param>
    void registerWith(string type, IParser* parser)
    {
        _prototypes.insert({ type, parser });
    }
public:
    IParser* select(string type)
    {
        IParser* parser = nullptr;
        if (_prototypes.contains(type))
        {
            parser = _prototypes[type];
        }
        return parser;
    }
    string toString()
    {
        return "ParserFactory";
    }
};

#endif
