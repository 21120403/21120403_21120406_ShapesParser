﻿#pragma once
#ifndef LISTSHAPE_H
#define LISTSHAPE_H
#include "Shapes.h"
#include"PrintShape.h"
#include"NormalDisplay.h"
#include"DisplayFile.h"
class ListShape
{
protected:
	shared_ptr<shared_ptr<Shape>[]> _list;//Quản lý các đối tượng hình học
	int _count;//Số lượng hình học hiện tại đang quản lý
	int _sz;//Số lượng hình học tối đa có thể quản lý
public:
	SHAPELIBRARY_API ListShape(int valueCount);
	SHAPELIBRARY_API ~ListShape();
	SHAPELIBRARY_API void insert(shared_ptr<Shape>);
	/// <summary> Hàm in ra thông tin sau khi đã sắp xếp dữ liệu</summary>
	SHAPELIBRARY_API void print();
	/// <summary> Hàm in ra thông tin sau khi đọc xong dữ liệu từ file </summary>
	SHAPELIBRARY_API void printContentFile(int countError);
	/// <summary>
	/// Sử dụng thuật toán MergeSort để sắp xếp danh sách tăng dần
	/// theo diện tích(Vì MergeSort có độ phức tạp O(nlog(n))
	/// </summary>
	SHAPELIBRARY_API void mergeSort(int left, int right);
	SHAPELIBRARY_API void merge(int left, int mid, int right);
};

#endif // !LISTSHAPE_H

