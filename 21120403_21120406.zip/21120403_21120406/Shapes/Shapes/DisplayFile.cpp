#include"pch.h"
#include"DisplayFile.h"
DisplayFile::DisplayFile()
{
	_countError = 0;
}
DisplayFile& DisplayFile::operator=(const DisplayFile& other)
{
	if (this != &other)
	{
		_listToDisplay = other._listToDisplay;
		_count = other._count;
		_countError = other._countError;
	}
	return *this;
}
DisplayFile::DisplayFile(shared_ptr<shared_ptr<Shape>[]> list, int valueCount, int valueError)
{
	_listToDisplay = list;
	_count = valueCount;
	_countError = valueError;
}
void DisplayFile::print()
{
	cout << "Tim thay " << _count << " hinh " << "/ " << _count + _countError << " hinh" << endl;
	for (int i = 0; i < _count; i++)
	{
		if (_listToDisplay[i]->getType() == "Circle")
		{
			string temp1 = _listToDisplay[i]->geoMetricInfo();
			float radius;
			radius = stof(temp1);
			cout << i + 1 << ". Hinh tron: Canh = " << radius << endl;
		}
		else if (_listToDisplay[i]->getType() == "Rectangle")
		{
			stringstream ss(_listToDisplay[i]->geoMetricInfo());
			string temp1, temp2;
			float width;
			float heigh;
			getline(ss, temp1, ',');
			getline(ss, temp2);
			width = stof(temp1);
			heigh = stof(temp2);
			cout << i + 1 << ". Hinh chu nhat: Rong = " << width << ", Cao = " << heigh << endl;
		}
		else if (_listToDisplay[i]->getType() == "Square")
		{
			string temp1 = _listToDisplay[i]->geoMetricInfo();
			float side;
			side = stof(temp1);
			cout << i + 1 << ". Hinh vuong: Canh = " << side << endl;
		}
		else if (_listToDisplay[i]->getType() == "Triangle")
		{
			stringstream ss(_listToDisplay[i]->geoMetricInfo());
			string temp1, temp2, temp3;
			float a, b, c;
			getline(ss, temp1, ',');
			getline(ss, temp2, ',');
			getline(ss, temp3);
			a = stof(temp1);
			b = stof(temp2);
			c = stof(temp3);
			cout << i + 1 << ". Hinh tam giac: Canh a = " << a << ", Canh b = " << b << ", Canh c = " << c << endl;
		}
		else if (_listToDisplay[i]->getType() == "Parallelogram")
		{
			stringstream ss(_listToDisplay[i]->geoMetricInfo());
			string temp1, temp2, temp3;
			float a, b, h;
			getline(ss, temp1, ',');
			getline(ss, temp2, ',');
			getline(ss, temp3);
			a = stof(temp1);
			b = stof(temp2);
			h = stof(temp3);
			cout << i + 1 << ". Hinh binh hanh: Canh a = " << a << ", Canh b = " << b << ", Cao = " << h << endl;
		}
	}
	if (_countError != 0)
	{
		cout << "Khong the doc duoc: " << _countError << " hinh" << endl;
	}
}
