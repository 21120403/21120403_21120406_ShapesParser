﻿#pragma once
#include"IParser.h"
#include"Parallelogram\Parallelogram.h"

class ParallelogramParser : public IParser {
public:
    /// <summary>
    /// Lấy các dữ liệu từ chuỗi string truyền vào
    /// </summary>
    /// <param name="Chuỗi string"></param>
    /// <returns>Các dữ liệu đã tách được</returns>
    shared_ptr<Shape> parse(string data)
    {
        stringstream ss(data);
        string temp;
        shared_ptr<Shape> result;

        getline(ss, temp, '=');

        string value1;
        getline(ss, value1, ',');
        float a = stof(value1);

        string temp2;
        getline(ss, temp2, '=');

        string value2;
        getline(ss, value2, ',');
        float b = stof(value2);

        getline(ss, temp2, '=');

        string value3;
        getline(ss, value3, '\n');
        float h = stof(value3);
        result = shared_ptr<Shape>(new Parallelogram(a, b, h));
        return result;
    }
};


