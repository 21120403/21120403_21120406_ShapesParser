﻿#include"pch.h"
#include"Reader.h"
shared_ptr<Reader> Reader::_reader = nullptr;
Reader::Reader()
{
	_countError = 0;
	fstream read;
	read.open("shapes.txt", ios::in);
	cout << "Dang doc tap tin shapes.txt..." << endl;
	if (!read.good())
	{
		throw exception("File opening failed");
	}
	else
	{
		string line;
		int size = 0;
		getline(read, line);
		_count = stoi(line);
		_readFile = make_shared<shared_ptr<string>[]>(_count);
		for (int i = 0; i < _count; i++)
		{
			try
			{
				getline(read, line);
				if (!isDataLineValid(line))
				{
					if (_countError == 0)//Kiểm ra, nếu đã bắt lỗi rồi thì sẽ không quăng ra ngoại lệ nữa
					{
						_countError++;
						throw exception("Read file malformed");
					}
					else
					{
						_countError++;
					}
				}
				else
				{
					_readFile[size] = make_shared<string>(line);
					size++;
				}
			}
			catch (const exception& e)
			{
				cout << "Exception occurred: " << e.what() << endl;
			}
		}
	}
	read.close();
}
shared_ptr<Reader> Reader::getInstance()
{
	if (_reader == nullptr)
	{
		_reader = shared_ptr<Reader>(new Reader());
		return _reader;
	}
	return _reader;
}
int Reader::getCount()
{
	return _count;
}
shared_ptr<shared_ptr<string>[]>Reader::getFile()
{
	return _readFile;
}
bool Reader::isDataLineValid(const string& line)
{
	regex pattern("(Square|Circle|Rectangle|Triangle|Parallelogram): (a|r|w)=\\d+(, (h|b)=\\d+)?(, (h|c)=\\d+)?");
	return regex_match(line, pattern);
}
int Reader::getCountError()
{
	return _countError;
}

