#include"pch.h"
#include <utility>
#include <limits.h>
#include"Rectangle.h"
float Rectangle::area()
{
	return _w * _h;
}
Rectangle::Rectangle(float w, float h)
{
	_w = w;
	_h = h;
}
string Rectangle::Info()
{
	return "Hinh chu nhat : Rong=" + to_string(_w) + " Cao=" + to_string(_h);
}
float Rectangle::perimeter()
{
	return (_w + _h) * 2;
}
string Rectangle::getType()
{
	return "Rectangle";
}
float  Rectangle::getWidth()
{
	return _w;
}
float Rectangle::getHigh()
{
	return _h;
}
string Rectangle::geoMetricInfo()
{
	string temp = ",";
	return to_string(_w) + temp + to_string(_h);
}