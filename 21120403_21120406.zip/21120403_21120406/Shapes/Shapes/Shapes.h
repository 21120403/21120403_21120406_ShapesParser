﻿#pragma once

#ifdef SHAPELIBRARY_EXPORTS
#define SHAPELIBRARY_API __declspec(dllexport)
#else
#define SHAPELIBRARY_API __declspec(dllimport)
#endif

#include<regex>
#include<iostream>
#include<string>
#include<exception>
#include<memory>
#include<string>
#include<vector>
#include<fstream>
#include<sstream>
#include <iomanip>
#include<math.h>
using std::cin;
using std::cout;
using std::endl;
using std::exception;
using std::shared_ptr;
using std::make_shared;
using std::string;
using std::vector; using std::fstream;
using std::ios;
using std::getline;
using std::stringstream; using std::fixed;
using std::to_string; using std::setprecision; using std::setw;

class Shape
{
public:
/// <summary> Hàm tính diện tích </summary>
/// <returns> Diện tích </returns>
	virtual float area() = 0;
/// <summary> Hàm lấy thông tin hình học </summary>
/// <returns> Thông tin của hình học </returns>
	virtual string Info() = 0;
/// <summary> Hàm tính chu vi hình học </summary>
/// <returns> Chu vi hình học: float </returns>
	virtual float perimeter() = 0;
/// <summary> Hàm lấy định dạng hình học(Square,Rectangle,Circle,Paralleogram,Triangle:string </summary>
/// <returns> Định dạng hình( </returns>
	virtual string getType() = 0;
/// <summary> Hàm lấy thông tin đầy đủ của một hình học: string </summary>
/// <returns> Thông tin hình học: string </returns>
	virtual string geoMetricInfo() = 0;
};