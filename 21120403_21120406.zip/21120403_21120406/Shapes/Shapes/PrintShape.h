﻿#include"Shapes.h"
#ifndef DISPLAY_H
class Display
{
protected:
	shared_ptr<shared_ptr<Shape>[]> _listToDisplay;//Danh sách các đối tượng hình học 
	int _count;//Số lượng các đối tượng hình học
public:
	SHAPELIBRARY_API Display();
	SHAPELIBRARY_API void virtual print() = 0;
};
#define DISPLAY_H
#endif // !DISPLAY_H


