#pragma once
#include"Shapes.h"

class Triangle : public Shape
{
protected:
	float _a;
	float _b;
	float _c;
public:
	SHAPELIBRARY_API Triangle(float, float, float);
	SHAPELIBRARY_API float area() override;
	SHAPELIBRARY_API string Info()override;
	SHAPELIBRARY_API float perimeter()override;
	SHAPELIBRARY_API string getType()override;
	SHAPELIBRARY_API float getA();
	SHAPELIBRARY_API float getB();
	SHAPELIBRARY_API float getC();
	SHAPELIBRARY_API string geoMetricInfo() override;
};
